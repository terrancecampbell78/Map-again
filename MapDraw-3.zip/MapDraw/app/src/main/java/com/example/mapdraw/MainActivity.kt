package com.example.mapdraw

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.location.LocationManager
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.*

enum class Tool(val label: String) { PAN("Pan"), FREE("Free"), LINE("Line"), CIRCLE("Circle"), TRI("Triangle"), RECT("Rect") }
class Stroke(var pts: List<GeoPoint>, val color: Int, val width: Float, val closed: Boolean)

class MainActivity : Activity() {
    private lateinit var map: MapView
    private val strokes = mutableListOf<Stroke>()
    private var tool = Tool.FREE
    private var color = Color.RED
    private var penWidth = 6f
    private var snap = false
    private val profs = listOf("car", "bike", "foot")
    private var prof = 0
    private var pending: String? = null
    private var name = "Drawing"
    private val UA = "MapDraw/1.0 (personal use; +https://github.com/terrancecampbell78/Map)"
    private val toolBtns = mutableMapOf<Tool, Button>()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; textSize = 12f; isAllCaps = false; minWidth = 0; minimumWidth = 0
        setOnClickListener { f() }
    }
    private fun bar(vararg v: View) = HorizontalScrollView(this).apply {
        addView(LinearLayout(this@MainActivity).apply { v.forEach { addView(it) } })
    }
    private fun refresh() { toolBtns.forEach { (t, b) -> b.alpha = if (t == tool) 1f else 0.45f } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val cfg = Configuration.getInstance()
        cfg.load(this, getSharedPreferences("osm", MODE_PRIVATE))
        cfg.userAgentValue = UA
        cfg.osmdroidBasePath = File(cacheDir, "osm2")
        cfg.osmdroidTileCache = File(cacheDir, "osm2/tiles")
        map = MapView(this).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(5.0)
            controller.setCenter(GeoPoint(39.0, -98.0))
            overlays.add(DrawOverlay())
        }
        val tools = Tool.values().map { t -> btn(t.label) { tool = t; refresh() }.also { toolBtns[t] = it } }
        val swatches = listOf(Color.RED, Color.BLUE, Color.GREEN, Color.BLACK, Color.YELLOW,
            Color.MAGENTA, Color.CYAN, Color.rgb(255, 136, 0), Color.WHITE).map { c ->
            Button(this).apply {
                setBackgroundColor(c)
                layoutParams = LinearLayout.LayoutParams(110, 110).apply { setMargins(6, 6, 6, 6) }
                setOnClickListener { color = c }
            }
        }
        val seek = SeekBar(this).apply {
            max = 30; progress = 6
            layoutParams = LinearLayout.LayoutParams(450, -2)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { penWidth = p.coerceAtLeast(1).toFloat() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        val snapB = btn("Snap: off") {}
        snapB.setOnClickListener { snap = !snap; snapB.text = if (snap) "Snap: on" else "Snap: off" }
        val profB = btn("Car") {}
        profB.setOnClickListener { prof = (prof + 1) % 3; profB.text = profs[prof].replaceFirstChar { it.uppercase() } }
        val actions = listOf(
            btn("Undo") { if (strokes.isNotEmpty()) strokes.removeAt(strokes.size - 1); map.invalidate() },
            btn("Clear") {
                AlertDialog.Builder(this).setMessage("Clear everything?")
                    .setPositiveButton("Clear") { _, _ -> strokes.clear(); map.invalidate() }
                    .setNegativeButton("Cancel", null).show()
            },
            snapB, profB,
            btn("Locate") { locate() },
            btn("Save") { save() },
            btn("Open") { openProj() },
            btn("GPX") { export("gpx") },
            btn("KML") { export("kml") }
        )
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(map, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bar(*tools.toTypedArray()))
        root.addView(bar(*(swatches + seek).toTypedArray()))
        root.addView(bar(*actions.toTypedArray()))
        setContentView(root)
        refresh()
    }

    override fun onResume() { super.onResume(); map.onResume() }
    override fun onPause() { super.onPause(); map.onPause() }

    inner class DrawOverlay : Overlay() {
        private var sx = 0f
        private var sy = 0f
        private var free = mutableListOf<GeoPoint>()
        private var live: Stroke? = null
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }

        private fun g(m: MapView, x: Float, y: Float): GeoPoint {
            val p = m.projection.fromPixels(x.toInt(), y.toInt())
            return GeoPoint(p.latitude, p.longitude)
        }

        private fun shape(m: MapView, x: Float, y: Float): Stroke {
            val pts: List<GeoPoint>
            var closed = true
            when (tool) {
                Tool.FREE -> { pts = free; closed = false }
                Tool.LINE -> { pts = listOf(g(m, sx, sy), g(m, x, y)); closed = false }
                Tool.CIRCLE -> {
                    val r = hypot(x - sx, y - sy)
                    pts = (0 until 48).map {
                        val a = it * 2 * PI / 48
                        g(m, sx + (r * cos(a)).toFloat(), sy + (r * sin(a)).toFloat())
                    }
                }
                Tool.TRI -> pts = listOf(g(m, (sx + x) / 2, sy), g(m, x, y), g(m, sx, y))
                else -> pts = listOf(g(m, sx, sy), g(m, x, sy), g(m, x, y), g(m, sx, y))
            }
            return Stroke(pts.toList(), color, penWidth, closed)
        }

        override fun onTouchEvent(e: MotionEvent, m: MapView): Boolean {
            if (tool == Tool.PAN) return false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.x; sy = e.y; free = mutableListOf(g(m, sx, sy)); live = null }
                MotionEvent.ACTION_MOVE -> {
                    if (tool == Tool.FREE) free.add(g(m, e.x, e.y))
                    live = shape(m, e.x, e.y)
                }
                MotionEvent.ACTION_UP -> {
                    live = null
                    if (tool == Tool.FREE) free.add(g(m, e.x, e.y))
                    val ok = if (tool == Tool.FREE) free.size > 3 else hypot(e.x - sx, e.y - sy) > 12
                    if (ok) {
                        val s = shape(m, e.x, e.y)
                        strokes.add(s)
                        if (snap && (tool == Tool.FREE || tool == Tool.LINE)) snapStroke(s)
                    }
                }
                MotionEvent.ACTION_CANCEL -> live = null
            }
            m.invalidate()
            return true
        }

        override fun draw(c: Canvas, m: MapView, shadow: Boolean) {
            if (shadow) return
            val proj = m.projection
            val pt = Point()
            val dp = m.resources.displayMetrics.density
            for (s in strokes + listOfNotNull(live)) {
                if (s.pts.size < 2) continue
                val path = Path()
                s.pts.forEachIndexed { i, p ->
                    proj.toPixels(p, pt)
                    if (i == 0) path.moveTo(pt.x.toFloat(), pt.y.toFloat()) else path.lineTo(pt.x.toFloat(), pt.y.toFloat())
                }
                if (s.closed) path.close()
                paint.color = s.color
                paint.strokeWidth = s.width * dp
                c.drawPath(path, paint)
            }
        }
    }

    private fun snapStroke(s: Stroke) {
        val src = s.pts
        val n = min(src.size, 25)
        val wp = (0 until n).map { src[(it.toLong() * (src.size - 1) / (n - 1).coerceAtLeast(1)).toInt()] }
        val coords = wp.joinToString(";") { "${it.longitude},${it.latitude}" }
        val url = "https://routing.openstreetmap.de/routed-${profs[prof]}/route/v1/driving/$coords?overview=full&geometries=geojson"
        toast("Snapping...")
        Thread {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 15000; c.readTimeout = 20000
                c.setRequestProperty("User-Agent", UA)
                val body = c.inputStream.bufferedReader().readText()
                val co = JSONObject(body).getJSONArray("routes").getJSONObject(0)
                    .getJSONObject("geometry").getJSONArray("coordinates")
                val out = (0 until co.length()).map { GeoPoint(co.getJSONArray(it).getDouble(1), co.getJSONArray(it).getDouble(0)) }
                runOnUiThread { s.pts = out; map.invalidate() }
            } catch (e: Exception) {
                runOnUiThread { toast("Snap failed: ${e.message}") }
            }
        }.start()
    }

    private fun locate() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 2); return
        }
        val lm = getSystemService(LocationManager::class.java)
        val l = listOf("gps", "network", "passive").mapNotNull {
            try { lm.getLastKnownLocation(it) } catch (e: Exception) { null }
        }.maxByOrNull { it.time }
        if (l == null) toast("No location available yet") else {
            map.controller.setZoom(16.0); map.controller.setCenter(GeoPoint(l.latitude, l.longitude))
        }
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r)
        if (rc == 2 && r.firstOrNull() == PackageManager.PERMISSION_GRANTED) locate()
    }

    private fun dir() = File(filesDir, "projects").apply { mkdirs() }

    private fun save() {
        val et = EditText(this).apply { setText(name) }
        AlertDialog.Builder(this).setTitle("Save as").setView(et).setPositiveButton("Save") { _, _ ->
            name = et.text.toString().trim().ifEmpty { "Drawing" }.replace(Regex("[^A-Za-z0-9 _-]"), "_")
            val a = JSONArray()
            for (s in strokes) a.put(JSONObject().put("c", s.color).put("w", s.width.toDouble()).put("z", s.closed)
                .put("p", JSONArray().also { j -> s.pts.forEach { j.put(JSONArray().put(it.latitude).put(it.longitude)) } }))
            File(dir(), "$name.json").writeText(a.toString())
            toast("Saved")
        }.setNegativeButton("Cancel", null).show()
    }

    private fun openProj() {
        val fs = dir().listFiles { f -> f.name.endsWith(".json") }?.sortedBy { it.name } ?: emptyList()
        if (fs.isEmpty()) { toast("No saved drawings"); return }
        AlertDialog.Builder(this).setTitle("Open").setItems(fs.map { it.nameWithoutExtension }.toTypedArray()) { _, i ->
            val a = JSONArray(fs[i].readText())
            strokes.clear()
            for (k in 0 until a.length()) {
                val o = a.getJSONObject(k)
                val p = o.getJSONArray("p")
                strokes.add(Stroke((0 until p.length()).map { GeoPoint(p.getJSONArray(it).getDouble(0), p.getJSONArray(it).getDouble(1)) },
                    o.getInt("c"), o.getDouble("w").toFloat(), o.getBoolean("z")))
            }
            name = fs[i].nameWithoutExtension
            strokes.firstOrNull()?.let { map.controller.setCenter(it.pts[0]) }
            map.invalidate()
        }.show()
    }

    private fun pts(s: Stroke) = if (s.closed) s.pts + s.pts[0] else s.pts

    private fun gpx(): String {
        val sb = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<gpx version=\"1.1\" creator=\"MapDraw\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n")
        strokes.forEachIndexed { i, s ->
            sb.append("<trk><name>Drawing ${i + 1}</name><trkseg>\n")
            for (p in pts(s)) sb.append("<trkpt lat=\"${p.latitude}\" lon=\"${p.longitude}\"/>\n")
            sb.append("</trkseg></trk>\n")
        }
        return sb.append("</gpx>").toString()
    }

    private fun kml(): String {
        val sb = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<kml xmlns=\"http://www.opengis.net/kml/2.2\"><Document>\n")
        strokes.forEachIndexed { i, s ->
            val k = String.format("ff%02x%02x%02x", Color.blue(s.color), Color.green(s.color), Color.red(s.color))
            sb.append("<Placemark><name>Drawing ${i + 1}</name><Style><LineStyle><color>$k</color><width>${s.width}</width></LineStyle></Style>")
            sb.append("<LineString><tessellate>1</tessellate><coordinates>")
            sb.append(pts(s).joinToString(" ") { "${it.longitude},${it.latitude},0" })
            sb.append("</coordinates></LineString></Placemark>\n")
        }
        return sb.append("</Document></kml>").toString()
    }

    private fun export(kind: String) {
        if (strokes.isEmpty()) { toast("Nothing drawn yet"); return }
        pending = if (kind == "gpx") gpx() else kml()
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
            .setType(if (kind == "gpx") "application/gpx+xml" else "application/vnd.google-earth.kml+xml")
            .putExtra(Intent.EXTRA_TITLE, "$name.$kind"), 1)
    }

    override fun onActivityResult(rc: Int, res: Int, data: Intent?) {
        super.onActivityResult(rc, res, data)
        val uri = data?.data
        if (rc == 1 && res == RESULT_OK && uri != null) {
            contentResolver.openOutputStream(uri)?.use { it.write((pending ?: "").toByteArray()) }
            toast("Exported")
        }
    }
}
